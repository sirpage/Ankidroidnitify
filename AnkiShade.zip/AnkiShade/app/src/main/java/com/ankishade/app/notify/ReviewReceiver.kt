package com.ankishade.app.notify

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.ankishade.app.R
import com.ankishade.app.data.AnkiBridge

class ReviewReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val bridge = AnkiBridge(ctx)
        when (intent.action) {
            "ACTION_REVEAL" -> {
                val cardId = intent.getLongExtra("cardId", -1L)
                val card = bridge.getCard(cardId) ?: return
                // Start audio if available (in a real app, use a foreground service)
                // ctx.startService(Intent(ctx, AudioService::class.java).putExtra("audioUri", card.audioUri))

                val actions = ReviewPendingIntents.buildAll(ctx, card.id, card.character)
                val noti = NotificationCompat.Builder(ctx, NotiIds.CHANNEL_REVIEWS)
                    .setSmallIcon(R.mipmap.ic_launcher_round)
                    .setContentTitle(card.character)
                    .setStyle(NotificationCompat.BigTextStyle()
                        .bigText("${card.pinyin ?: ""}\n${card.definition ?: ""}"))
                    .addAction(0, "Again", actions.againPI)
                    .addAction(0, "Hard", actions.hardPI)
                    .addAction(0, "Good", actions.goodPI)
                    .addAction(0, "Easy", actions.easyPI)
                    .build()

                NotificationManagerCompat.from(ctx).notify(NotiIds.REVIEW_NOTI_ID, noti)
            }
            "ACTION_RATE" -> {
                val cardId = intent.getLongExtra("cardId", -1L)
                val ease = intent.getIntExtra("ease", 3)
                bridge.answerCard(cardId, ease)

                val next = bridge.getNextDueCard()
                if (next == null) {
                    NotificationManagerCompat.from(ctx).cancel(NotiIds.REVIEW_NOTI_ID)
                } else {
                    val actions = ReviewPendingIntents.buildAll(ctx, next.id, next.character)
                    val noti = NotificationCompat.Builder(ctx, NotiIds.CHANNEL_REVIEWS)
                        .setSmallIcon(R.mipmap.ic_launcher_round)
                        .setContentTitle(next.character)
                        .setContentText("Tap Reveal to see meaning")
                        .setContentIntent(actions.revealPI)
                        .addAction(0, "Reveal", actions.revealPI)
                        .addAction(0, "Again", actions.againPI)
                        .addAction(0, "Hard", actions.hardPI)
                        .addAction(0, "Good", actions.goodPI)
                        .addAction(0, "Easy", actions.easyPI)
                        .build()
                    NotificationManagerCompat.from(ctx).notify(NotiIds.REVIEW_NOTI_ID, noti)
                }
            }
        }
    }
}
