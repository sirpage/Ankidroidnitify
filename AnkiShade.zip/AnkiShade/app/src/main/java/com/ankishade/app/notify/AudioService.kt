package com.ankishade.app.notify

import android.app.Notification
import android.app.Service
import android.content.Intent
import android.os.IBinder

class AudioService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // TODO: play audio from URI or TTS; run as foreground with small persistent notification
        val notif: Notification = Notification.Builder(this, NotiIds.CHANNEL_REVIEWS)
            .setContentTitle("Playing audio")
            .setContentText("...")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .build()
        startForeground(2024, notif)
        stopForeground(STOP_FOREGROUND_DETACH)
        stopSelf()
        return START_NOT_STICKY
    }
}
