package com.ankishade.app.data

data class Card(
    val id: Long,
    val character: String,
    val pinyin: String? = null,
    val definition: String? = null,
    val audioUri: String? = null
)
