package com.ankishade.app.data

import android.content.Context

/**
 * Replace stub implementations with actual AnkiDroid API calls.
 * For now, we return a fake card so you can test notifications.
 */
class AnkiBridge(private val context: Context) {

    private var fakeCounter = 0L

    fun getNextDueCard(): Card? {
        // TODO: query AnkiDroid for an actual due card
        fakeCounter += 1
        return Card(
            id = fakeCounter,
            character = listOf("你","好","学","习","中","文").random(),
            pinyin = "nǐ hǎo",
            definition = "hello; hi (fake)",
            audioUri = null // or a real file uri if available
        )
    }

    fun getCard(cardId: Long): Card? {
        // TODO: fetch full fields for specific cardId
        return Card(
            id = cardId,
            character = "你",
            pinyin = "nǐ",
            definition = "you (singular)",
            audioUri = null
        )
    }

    fun answerCard(cardId: Long, ease: Int) {
        // TODO: send rating back to AnkiDroid
        // ease: 1=Again, 2=Hard, 3=Good, 4=Easy
    }
}
