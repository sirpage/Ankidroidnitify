package com.ankishade.app.notify

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.ankishade.app.R
import com.ankishade.app.data.AnkiBridge

object NotiIds {
    const val CHANNEL_REVIEWS = "reviews"
    const val REVIEW_NOTI_ID = 1010
}

class ReviewNotifier(private val ctx: Context) {

    private val bridge = AnkiBridge(ctx)

    init { ensureChannels() }

    private fun ensureChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(
                NotiIds.CHANNEL_REVIEWS,
                "Anki Reviews",
                NotificationManager.IMPORTANCE_HIGH
            )
            val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(ch)
        }
    }

    fun postNextCardOrHint() {
        val card = bridge.getNextDueCard()
        val builder = NotificationCompat.Builder(ctx, NotiIds.CHANNEL_REVIEWS)
            .setSmallIcon(R.mipmap.ic_launcher_round)
            .setPriority(NotificationCompat.PRIORITY_HIGH)

        if (card == null) {
            builder.setContentTitle("No cards due")
                .setContentText("You're all caught up!")
        } else {
            val actions = ReviewPendingIntents.buildAll(ctx, card.id, card.character)
            builder.setContentTitle(card.character)
                .setContentText("Tap Reveal to see meaning")
                .setContentIntent(actions.revealPI)
                .addAction(0, "Reveal", actions.revealPI)
                .addAction(0, "Again", actions.againPI)
                .addAction(0, "Hard", actions.hardPI)
                .addAction(0, "Good", actions.goodPI)
                .addAction(0, "Easy", actions.easyPI)
                .setAutoCancel(false)
        }
        NotificationManagerCompat.from(ctx).notify(NotiIds.REVIEW_NOTI_ID, builder.build())
    }
}
