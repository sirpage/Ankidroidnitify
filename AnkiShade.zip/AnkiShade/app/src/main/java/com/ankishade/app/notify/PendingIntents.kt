package com.ankishade.app.notify

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Bundle

data class ReviewActions(
    val revealPI: PendingIntent,
    val againPI: PendingIntent,
    val hardPI: PendingIntent,
    val goodPI: PendingIntent,
    val easyPI: PendingIntent
)

object ReviewPendingIntents {

    fun buildAll(ctx: Context, cardId: Long, character: String): ReviewActions {
        val base = Bundle().apply {
            putLong("cardId", cardId)
            putString("char", character)
        }
        val revealPI = pi(ctx, "ACTION_REVEAL", base)
        val againPI  = pi(ctx, "ACTION_RATE", with(Bundle(base)) { putInt("ease", 1); this })
        val hardPI   = pi(ctx, "ACTION_RATE", with(Bundle(base)) { putInt("ease", 2); this })
        val goodPI   = pi(ctx, "ACTION_RATE", with(Bundle(base)) { putInt("ease", 3); this })
        val easyPI   = pi(ctx, "ACTION_RATE", with(Bundle(base)) { putInt("ease", 4); this })

        return ReviewActions(revealPI, againPI, hardPI, goodPI, easyPI)
    }

    private fun pi(ctx: Context, action: String, extras: Bundle): PendingIntent {
        val req = (action.hashCode() xor extras.hashCode())
        val intent = Intent(ctx, ReviewReceiver::class.java).apply {
            this.action = action
            putExtras(extras)
        }
        return PendingIntent.getBroadcast(
            ctx, req, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }
}
