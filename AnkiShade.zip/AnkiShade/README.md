# AnkiShade (Notification-based AnkiDroid companion)

**What it does now (stub):**
- Posts a heads-up notification with a single character
- Tap **Reveal** to expand with pinyin + definition
- Rate with **Again/Hard/Good/Easy**; it cycles to a new fake card

**What you need to wire up:**
- In `data/AnkiBridge.kt`, replace the stub methods with real **AnkiDroid API** calls:
  - `getNextDueCard()` → return a real due card and its fields (character, pinyin, definition, audio URI if any)
  - `getCard(cardId)` → fetch full fields for a specific card
  - `answerCard(cardId, ease)` → send back the user's rating (1..4)

**Build & install:**
1. Open this folder in **Android Studio (Giraffe+ recommended)**.
2. Let it download the Android SDK & Gradle as needed.
3. Build and run on your device (enable developer mode + USB debugging or use an APK build).
4. On first launch, grant **POST_NOTIFICATIONS** permission. The app posts a test notification.
5. Set battery to **Unrestricted** for smoother background behavior (optional).

**Audio on reveal:**
- Implement playback in `notify/AudioService.kt` using TTS or a real audio file from the note.
- Start the service from `ReviewReceiver` on ACTION_REVEAL.

**Android 13–16 notes:**
- Use runtime permission for notifications.
- Consider using a Foreground Service for audio.
- You can keep the entire review flow inside notifications by updating the same notification ID.

**License:** MIT (adjust as you like).
